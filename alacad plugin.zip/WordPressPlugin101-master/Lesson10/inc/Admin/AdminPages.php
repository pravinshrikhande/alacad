<?php 

namespace Inc\Admin;

/**
* 
*/
class AdminPages
{
	
	function __construct()
	{}
}