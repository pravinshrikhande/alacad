# Plugin 101 Series

Full list of sections and features we will build during the series of Tutorials

* Modular Administration Area
* CPT Manager
* Custom Taxonomy Manager
* Widget to Upload and Display media in sidebars
* Post and Pages Gallery integration
* Testimonial section: Comment in the front-end, Admins can approve comments, select which comments to display
* Custom template section
* Ajax based Login/Register system
* Membership protected area
* Chat system